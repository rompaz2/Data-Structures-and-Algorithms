class Node
{
    public Node left = null;
    public Node middle = null;
    public Node right = null;
    public int isSentinel = 0;
    public Node p = null;
    public Key key = null;
    public Value value = null;
    public int size = 1;
    public Value sum = null;

    public Node() {}

    public void changeParent(Node newParent)
    {
        this.p = newParent;
    }

    public void changeLeft(Node newLeft)
    {
        this.left = newLeft;
    }

    public void changeMiddle(Node newMiddle)
    {
        this.middle = newMiddle;
    }

    public void changeRight(Node newRight)
    {
        this.right = newRight;
    }

    public void changeKey(Key newKey)
    {
        this.key = newKey;
    }

    public void changeValue(Value newValue)
    {
        this.value = newValue;
    }

    public void addToSum(Value v)
    {
        if (v == null)
        {
            return;
        }
        if (this.sum == null)
        {
            this.sum = v.createCopy();
        }
        else
        {
            this.sum.addValue(v.createCopy());
        }
    }


    public boolean isLeaf()
    {
        if (this.left == null)
            return true;
        if (this.left.key == null && this.left.isSentinel == 0)
            return true;
        else
            return false;
    }


}