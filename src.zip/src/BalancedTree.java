class BalancedTree
{
    public Node root = null;
    public BalancedTree()
    {
        this.root = createSentinel(1);
        Node left = createSentinel(-1);
        Node middle = createSentinel(1);
        set_children(this.root, left, middle, null);
    }

    public int compareNodeKeys(Node a, Node b)
    {
        if (a.isSentinel == -1)
            return -1;
        else if (b.isSentinel == -1)
            return 1;
        else if (a.isSentinel == 1)
            return 1;
        else if (b.isSentinel == 1)
            return -1;
        else
            return a.key.compareTo(b.key);
    }

    public Node createSentinel(int sign)
    {
        Node s = new Node();
        s.isSentinel = sign;
        s.size = 0;
        return s;
    }

    public void updateKey(Node x)
    {
        int xleftSize, xmiddleSize = 0, xrightSize = 0;
        xleftSize = x.left.size;
        if (x.left.isSentinel == 0) {
            x.changeKey(x.left.key);
            x.changeValue(x.left.value);
        }
        if (x.middle != null) {
            xmiddleSize = x.middle.size;
            if (x.middle.isSentinel == 1)
            {
                x.key = null;
                x.isSentinel = 1;
            }
            else if (x.middle.isSentinel == 0) {
                x.changeKey(x.middle.key);
                x.changeValue(x.middle.value);
            }
        }
        if (x.right != null) {
            xrightSize = x.right.size;
            if (x.right.isSentinel == 1)
            {
                x.key = null;
                x.isSentinel = 1;
            }
            x.changeKey(x.right.key);
            x.changeValue(x.right.value);
        }
        x.size = xleftSize + xmiddleSize + xrightSize;

    }

    public void set_children(Node x, Node l, Node m, Node r)
    {
        x.changeLeft(l);
        x.changeMiddle(m);
        x.changeRight(r);
        if (l == null)
            return;
        l.changeParent(x);
        x.size = l.size;
        x.addToSum(l.sum);
        if (m != null) {
            m.changeParent(x);
            x.size += m.size;
            x.addToSum(m.sum);
            x.isSentinel = m.isSentinel;
        }
        if (r != null) {
            r.changeParent(x);
            x.size += r.size;
            x.addToSum(r.sum);
            x.isSentinel = r.isSentinel;
        }
        updateKey(x);
    }

    public Node insertAndSplit(Node x, Node z)
    {
        Node l = x.left;
        Node m = x.middle;
        Node r = x.right;
        if(r == null || (r.key == null && r.isSentinel == 0))
        {
            if(compareNodeKeys(z, l) < 0)
            {
                set_children(x,z,l,m);
            }

            else if(compareNodeKeys(z, m) < 0)
            {
                set_children(x,l,z,m);
            }
            else
            {
                set_children(x,l,m,z);
            }
            while (x != null)
            {
                x = x.p;
                if (x == null)
                    break;
                x.sum.addValue(z.sum.createCopy());
                x.size = x.size + 1;
            }
            return null;
        }
        Node y = new Node();

        if(compareNodeKeys(z, l) < 0)
        {
            set_children(x,z,l,null);
            set_children(y,m,r,null);
        }
        else if(compareNodeKeys(z, m) < 0)
        {
            set_children(x,l,z,null);
            set_children(y,m,r,null);
        }
        else if(compareNodeKeys(z, r) < 0)
        {
            set_children(x,l,m,null);
            set_children(y,z,r,null);
        }
        else
        {
            set_children(x,l,m,null);
            set_children(y,r,z,null);
        }
        return y;
    }

    public void insert(Key newKey, Value newValue)
    {
        Node z = new Node();
        z.key = newKey.createCopy();
        z.value = newValue.createCopy();
        z.sum = z.value.createCopy();
        if (this.root == null)
            return;
        Node y = this.root;
        if (y.key == null && y.left.isSentinel == -1 && y.middle.isSentinel == 1 && y.left.isLeaf() && y.middle.isLeaf())
        {
            set_children(this.root, y.left, z,  y.middle);
            return;
        }

        while (!(y.isLeaf()))
        {
            if(compareNodeKeys(z, y.left) < 0)
                y = y.left;
            else if(compareNodeKeys(z, y.middle) < 0)
                y = y.middle;
            else
            {
                if (y.right == null)
                {
                    System.out.println(this.root);
                }
                y = y.right;
            }

        }
        if (y.p == null)
            return;
        Node x = y.p;
        z = insertAndSplit(x, z);
        while (x != this.root && x!= null)
        {
            x = x.p;
            if(z != null)
                z = insertAndSplit(x,z);
            else
                updateKey(x);
        }
        if (z != null)
        {
            Node w = new Node();
            set_children(w,x,z,null);
            this.root = w;
        }
    }

    public Node borrowAndMerge(Node y)
    {
        Node z = y.p;
        Node x = new Node();

        if (y == z.left)
        {
            x = z.middle;

            if(x.right != null)
            {
                set_children(y,y.left,x.left,null);
                set_children(x,x.middle,x.right,null);
            }
            else
            {
                set_children(x,y.left,x.left,x.middle);
                y = null;
                set_children(z,x,z.right,null);

            }
            return z;
        }
        if (y == z.middle) {
            x = z.left;
            if (x.right != null) {
                set_children(y, x.right, y.left, null);
                set_children(x, x.left, x.middle, null);
            } else {
                set_children(x, x.left, x.middle, y.left);
                y = null;
                set_children(z, x, z.right, null);
            }
            return z;
        }

        x = z.middle;
        if(x.right != null)
        {
            set_children(y,x.right,y.left,null);
            set_children(x,x.left,x.middle,null);
        }
        else
        {
            set_children(x,x.left,x.middle,y.left);
            y = null;
            set_children(z,z.left,x,null);
        }
        return z;
    }

    public void delete(Key key) {
        Node x = keySearch(this.root, key);
        if (x == null)
            return;
        Node y = x.p;
        y.size = y.size - 1;
        if (x == y.left) {
            set_children(y, y.middle, y.right, null);
        }
        else if (x == y.middle) {
            set_children(y, y.left, y.right, null);
        }
        else {
            set_children(y, y.left, y.middle, null);
        }
        x = null;
        int b1 = 1;
        int b2 = 1;
        int b3 = 1;
        if (y.left == null)
            b1 = 0;
        if (y.middle == null)
            b2 = 0;
        if (y.right == null)
            b3 = 0;
        if (b1 + b2 + b3 == 2)
        {
            y = y.p;
            while (y != null)
            {
                y.sum = y.left.sum.createCopy();
                if (y.right != null) {
                    y.sum.addValue(y.middle.sum.createCopy());
                    y.sum.addValue(y.right.sum.createCopy());
                }
                if (y.middle != null) {
                    y.sum.addValue(y.middle.sum.createCopy());
                }
                y.size = y.size - 1;
                updateKey(y);
                y = y.p;
            }
        }
         else {
            while (y != null) {
                if (y.middle == null) {
                    if (y != this.root) {
                        y = borrowAndMerge(y);
                    }
                    else {
                        this.root = y.left;
                        y.left.p = null;
                        y = null;
                        return;
                    }
                } else {
                    y.size = y.size - 1;
                    updateKey(y);
                    y = y.p;
                }
            }
        }

    }

    public Node keySearch(Node x, Key key) {
        Node dummyKey = new Node();
        dummyKey.key = key;
        if (x.isLeaf())
        {
            if (x.key !=null && compareNodeKeys(x, dummyKey) == 0)
            {
                return x;
            }
            else
                return null;
        }
        if (compareNodeKeys(dummyKey, x.left) <= 0)
        {
            return keySearch(x.left, key);
        }
        else if (compareNodeKeys(dummyKey, x.middle) <= 0)
        {
            return keySearch(x.middle, key);
        }
        else
        {
            if (x.right != null)
                return keySearch(x.right, key);
            else
                return null;
        }
    }

    public Value search(Key key)
    {
        Node x = keySearch(this.root, key);
        if (x == null)
            return null;
        return x.value.createCopy();
    }

    public int rank(Key key)
    {
        Node x = keySearch(this.root, key);
        if (x == null)
            return 0;
        int rank = 1;
        Node y = x.p;
        if (y == null)
            return 1;
        while (y != null)
        {
            if (x == y.middle)
            {
                rank = rank + y.left.size;
            }
            else if (x == y.right)
            {
                rank = rank + y.left.size + y.middle.size;
            }
            x = y;
            y = y.p;
        }
        return rank;
    }

    public Key select(int index)
    {
        if (this.root.key == null && this.root.isSentinel == 0)
        {
            return null;
        }
        if (this.root.size < index)
        {
            return null;
        }
        if (index < 1)
        {
            return null;
        }
        Key k = selectRec(this.root, index);
        return k;
    }

    public Key selectRec(Node x, int index)
    {
        if (x == null)
            return null;
        if (x.size < index)
            return null;
        if (x.isLeaf())
            return x.key.createCopy();
        int s_left = x.left.size;
        int s_left_middle = x.middle.size + x.left.size;
        if (index <= s_left)
        {
            return selectRec(x.left, index);
        }
        else if (index <= s_left_middle)
        {
            return selectRec(x.middle, index - s_left);
        }
        else
        {
            return selectRec(x.right, index - s_left_middle);
        }
    }

    public Value sumValuesInInterval(Key key1, Key key2)
    {
        return sumOfIntervalsRec(this.root, key1, key2);
    }

    public Value sumOfIntervalsRec(Node x, Key key1, Key key2)
    {
        Value sum = null;
        Value temp = null;
        Value temp1 = null;
        Value temp2 = null;
        Node dummyKey1 = new Node();
        Node dummyKey2 = new Node();
        dummyKey1.key = key1;
        dummyKey2.key = key2;
        if (x == null || (x.key == null && x.isSentinel == 0)) {
            return null;
        }
        if (x.isLeaf() || compareNodeKeys(x.left,x.middle) == 0) {
            if ((compareNodeKeys(dummyKey1, x) <= 0) && (compareNodeKeys(x, dummyKey2) <= 0)) {
                return x.sum.createCopy();
            }
            else {
                return null;
            }
        }
        if (compareNodeKeys(dummyKey1, x) > 0)
        {
            return null;
        }
        boolean l_smaller_than_key1 = compareNodeKeys(dummyKey1, x.left) > 0;
        boolean l_bigger_than_key2 = compareNodeKeys(dummyKey2, x.left) < 0;
        boolean m_smaller_than_key1 = compareNodeKeys(dummyKey1, x.middle) > 0;
        boolean m_bigger_than_key2 = compareNodeKeys(dummyKey2, x.middle) < 0;

        if (l_smaller_than_key1) {
            temp = sumOfIntervalsRec(x.right, key1, key2);
            if (temp != null) {
                if (sum != null)
                    sum.addValue(temp);
                else
                    sum = temp;
            }
            if (!m_smaller_than_key1) {
                temp1 = sumOfIntervalsRec(x.middle, key1, key2);
                if (temp1 != null) {
                    if (sum != null)
                        sum.addValue(temp1);
                    else
                        sum = temp1;
                }
            }
        }
        else {//l bigger than key1
            temp = sumOfIntervalsRec(x.left, key1, key2);
            if (temp != null) {
                if (sum != null)
                    sum.addValue(temp);
                else
                    sum = temp;
            }
            if (!l_bigger_than_key2){
                temp1 = sumOfIntervalsRec(x.middle, key1, key2);
                if (temp1 != null) {
                    if (sum != null)
                        sum.addValue(temp1);
                    else
                        sum = temp1;
                }
                if (!m_bigger_than_key2){
                    temp2 = sumOfIntervalsRec(x.right, key1, key2);
                    if (temp2 != null) {
                        if (sum != null)
                            sum.addValue(temp2);
                        else
                            sum = temp2;
                    }
                }
            }
        }
        return sum;
    }
}